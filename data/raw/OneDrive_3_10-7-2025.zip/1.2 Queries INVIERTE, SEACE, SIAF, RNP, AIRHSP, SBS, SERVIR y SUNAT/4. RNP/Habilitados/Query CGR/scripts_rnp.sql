
--Consulta de la Empresa según RNP
SELECT distinct a.numero_de_ruc,rnp,a.nombre_o_razon_social,(Select descripcion from rnp.BD_RNP_CO_TIPO_REGISTRO where tipo=a.tipo) tipo,
a.nacionalidad,a.tipo_personeria,a.tipo_sociedad,a.direccion,a.departamento,a.provincia,a.distrito,a.ubigeo,a.pais,a.telefono,a.correo,a.capacidad_maxima_contratacion,
to_date(a.fecha_de_aprobacion,'dd/mm/yyyy') fecha_de_aprobacion,to_date('06/06/2079','dd/mm/yyyy') fecha_validez,a.fecha_registro,'VIGENTE' VIGENCIA_RNP 
FROM rnp.bd_rnp_rnp_reportes a
where numero_de_ruc='20100010217'
UNION ALL
SELECT distinct b.ruc numero_de_ruc,b.no_exp rnp,c.BUPR_RAZSOCIAL as nombre_o_razon_social,(Select descripcion from rnp.BD_RNP_CO_TIPO_REGISTRO where tipo=b.tipo) tipo,
'' nacionalidad,c.bupr_tipo_persona tipo_personeria,'' tipo_sociedad,'' direccion,'' departamento,'' provincia,'' distrito,'' ubigeo,c.bupr_pais pais,
'' telefono,'' correo,'' capacidad_maxima_contratacion,b.f_aprob fecha_de_Aprobacion,b.f_validez fecha_validez,(select distinct to_date(fecha_registro,'dd/mm/yyyy') fecha_registro from rnp.bd_rnp_rnp_reportes) fecha_registro,
'HISTORICO' VIGENCIA_RNP 
FROM rnp.registro_ta_rnp_vigencia b
left join rnp.BD_RNP_BUSQUEDA_PROVEEDOR c on
b.ruc=c.bupr_ruc and b.no_exp=c.bupr_noexp
where b.ruc='20100010217' and 
(select distinct to_date(fecha_registro) from rnp.bd_rnp_rnp_reportes) not between f_aprob and f_validez;

--Consulta para identificar los Representantes, Socios y Organos Administrativos de los proveedores
with emp as
	(
    	--select LT_RUC, RAZSOCIAL, NO_EXP, TIPO, F_APROB, F_APROB_MANUAL, PN_PJ, ID_TIPO_TRAMITE,F_REGISTRO
    	--from TMP_B01      
        
        SELECT 
        trim(LT_RUC) as LT_RUC, trim(RAZSOCIAL) as RAZSOCIAL, NO_EXP, TIPO, F_APROB, F_APROB_MANUAL, trim(PN_PJ) as PN_PJ, ID_TIPO_TRAMITE,F_REGISTRO
        FROM rnp.REGISTRO_BASE01 WHERE LT_RUC ='20100010217' 
	),
    rnp_exp as
    (
        SELECT B01.LT_RUC, MAX(B01.NO_EXP) as NO_EXP	
        FROM emp B01
        INNER JOIN (
                    SELECT LT_RUC ,MAX(
                             CASE 
                                WHEN ID_TIPO_TRAMITE IN (6,7,37,38,203,204,287,288) THEN F_APROB_MANUAL 
                                WHEN ID_TIPO_TRAMITE IN (174,175,181,182, 188,189,283,284) THEN F_APROB
                                WHEN ID_TIPO_TRAMITE IN (5,8,292,291,25,27,31,165,54) THEN F_REGISTRO
                                ELSE F_APROB 
                            END 
                          ) AS FECHA
                    FROM emp GROUP BY LT_RUC
                   ) DATA ON B01.LT_RUC = DATA.LT_RUC 
                            AND  (
                                ( B01.ID_TIPO_TRAMITE IN (6,7,37,38,203,204,287,288) AND ( B01.F_APROB_MANUAL = DATA.FECHA OR (B01.F_APROB_MANUAL IS NULL AND DATA.FECHA IS NULL))) 
                                OR ( B01.ID_TIPO_TRAMITE IN (174,175,181,182, 188,189,283,284) AND (B01.F_APROB = DATA.FECHA OR (B01.F_APROB IS NULL AND DATA.FECHA IS NULL)))
                                OR ( B01.ID_TIPO_TRAMITE IN (5,8,292,291,25,27,31,165,54) AND (B01.F_REGISTRO = DATA.FECHA OR (B01.F_REGISTRO IS NULL AND DATA.FECHA IS NULL)))
                                )
        GROUP BY B01.LT_RUC
    )
    --Consulta información histórica de Composición Proveedor
	SELECT X.RUC_COMPOSICION,X.NOMBRE_PROVEEDOR,X.TIPO_COMP,X.CARGO,X.COD_IDE,X.DE_IDE,X.NRO_DOC,UPPER(X.NOMBRES) AS NOMBRES,X.PORCENTAJE,
	X.VALORTOTALACCIONES,X.NU_ACCIONES,X.FECHA_REGISTRO,X.FH_INGRESO,X.FH_SALIDA,X.VIGENCIA
	FROM 
    (
        --socio modificado:
        SELECT
            s.lt_ruc RUC_COMPOSICION,
            emp.RAZSOCIAL NOMBRE_PROVEEDOR,
            'SOCIO' TIPO_COMP,
            '' CARGO,
            S.COD_IDE,
            CASE
                WHEN S.COD_IDE IS NULL AND S.NRO_DOC IS NOT NULL  THEN 'NO ESPECIFICADO' 
                WHEN S.COD_IDE IS NULL AND S.NU_RUC IS NULL  THEN 'NO ESPECIFICADO' 
                WHEN S.COD_IDE IS NULL AND S.NU_RUC IS NOT NULL THEN 'REG. UNICO DE CONTRIBUYENTES' 
                ELSE D.DE_IDE
            END DE_IDE,  		
            S.NRO_DOC,
            NVL(S.NOMBRES, NVL(REPLACE(S.RAZSOCIAL,'   ',' '),(NVL(S.AP_PATERNO,'') || ' ' ||NVL(S.AP_MATERNO,'') || ' ' || NVL(S.NO_NOMBRE,'')))) NOMBRES,
            NVL(CAST(S.PORCENTAJE AS FLOAT),S.NU_POR_ACCIONES) AS PORCENTAJE,
            CAST(TO_NUMBER(S.VALORTOTALACCIONES) AS VARCHAR2(20)) VALORTOTALACCIONES,
            CAST(TO_NUMBER(S.NU_ACCIONES) AS VARCHAR2(20)) NU_ACCIONES,
            TO_CHAR(S.FECHA_REGISTRO,'DD/MM/YYYY') AS FECHA_REGISTRO,
            TO_CHAR(S.FH_INGRESO,'DD/MM/YYYY') AS FH_INGRESO,
            '' FH_SALIDA,
            CASE 
                WHEN S.ID_SOCIO in (SELECT ID_SOCIO FROM rnp.REGISTRO_TA_SOCIO WHERE NO_EXP=rnp_exp.NO_EXP) THEN 1
                ELSE 0
            END VIGENCIA,
            S.ID_SOCIO_A ID_TABLA
            FROM rnp.REGISTRO_TA_SOCIO_A S 
            LEFT JOIN rnp.bd_REGISTRO_CO_DOCIDENTIDAD D ON S.COD_IDE = D.COD_IDE
            inner join emp on s.lt_ruc=emp.lt_ruc
            inner join rnp_exp on s.lt_ruc=rnp_exp.lt_ruc
            WHERE S.NO_EXP=rnp_exp.NO_EXP
            -------------------------------------------------------------------
            UNION
            ---representante modificado:
            SELECT
            R.ruc_proveedor RUC_COMPOSICION,
            emp.RAZSOCIAL NOMBRE_PROVEEDOR,
            'REPRESENTANTE' TIPO_COMP,
            '' CARGO,
            R.COD_IDE,
            CASE
                WHEN R.COD_IDE IS NULL AND R.NRO_DOC IS NOT NULL  THEN 'NO ESPECIFICADO' 
                WHEN R.COD_IDE IS NULL AND R.NU_RUC IS NULL  THEN 'NO ESPECIFICADO' 
                WHEN R.COD_IDE IS NULL AND R.NU_RUC IS NOT NULL THEN 'REG. UNICO DE CONTRIBUYENTES' 
                ELSE D.DE_IDE
            END DE_IDE,          
            NVL(R.NRO_DOC,R.NU_RUC) NRO_DOC,
            NVL(REPLACE(R.RAZSOCIAL,'   ',' '),(NVL(R.AP_PATERNO,'') || ' ' ||NVL(R.AP_MATERNO,'') || ' ' || NVL(R.NO_NOMBRE,''))) NOMBRES,        
            null PORCENTAJE, null VALORTOTALACCIONES, null NU_ACCIONES,       
            TO_CHAR(R.FECHA_REGISTRO,'DD/MM/YYYY') AS FECHA_REGISTRO,
            TO_CHAR(R.FEC_INGRESO,'DD/MM/YYYY') AS FH_INGRESO,        
            '' FH_SALIDA,
            CASE 
                WHEN R.ID_REPRESENTANTE in (SELECT ID_REPRESENTANTE FROM rnp.BD_REGISTRO_TA_REPRESENTANTE WHERE NO_EXP=rnp_exp.NO_EXP) THEN 1
                ELSE 0
            END VIGENCIA,
            R.ID_REPRESENTANTE_A ID_TABLA
            FROM rnp.BD_REGISTRO_TA_REPRESENTANTE_A R 
            LEFT JOIN rnp.BD_REGISTRO_CO_DOCIDENTIDAD D ON D.COD_IDE = R.COD_IDE
            INNER JOIN rnp.REGISTRO_BASE01_A B ON R.CO_EXP_RNC=B.CO_EXP_RNC
            inner join emp on R.ruc_proveedor=emp.lt_ruc
            inner join rnp_exp on r.ruc_proveedor=rnp_exp.lt_ruc
            WHERE R.ACTIVO=1 and R.NO_EXP=rnp_exp.NO_EXP
            AND NOT (R.COD_IDE IS NULL AND R.NRO_DOC IS NULL AND R.NU_RUC IS NULL AND R.RAZSOCIAL IS NULL AND R.AP_PATERNO IS NULL)
            --------------------------------------------------
            UNION  
            --ORGANO DE ADMINISTRACION MODIFICADO
            SELECT 
            oa.lt_ruc RUC_COMPOSICION,
            emp.RAZSOCIAL NOMBRE_PROVEEDOR,
            'ORGANO ADMNISTRATIVO' TIPO_COMP,
            CA.DE_CARGO CARGO,
            OA.ID_TIPO_DOC COD_IDE,
            CD.DE_IDE,
            OA.NUM_DOC NRO_DOC, 
            REPLACE(OA.APELLIDOS_NOMBRES,'  ',' ') NOMBRES,
            null PORCENTAJE, null VALORTOTALACCIONES,null NU_ACCIONES,
            TO_CHAR(B.F_REGISTRO,'DD/MM/YYYY') AS FECHA_REGISTRO,
            TO_CHAR(OA.FECHA_ING,'DD/MM/YYYY') AS FH_INGRESO,        
            '' FH_SALIDA,        
            CASE 
                WHEN OA.ID_ORG_ADM in (SELECT ID_ORG_ADM FROM rnp.REGISTRO_ORGANO_ADMINISTRACION WHERE NO_EXP=rnp_exp.NO_EXP AND ACTIVO=1) THEN 1
                ELSE 0 END VIGENCIA,
            OA.ID_ORG_ADM_A ID_TABLA
            FROM rnp.REG_ORG_ADMINISTRACION_A OA
            LEFT JOIN rnp.BD_REGISTRO_CO_DOCIDENTIDAD CD ON OA.ID_TIPO_DOC = CD.COD_IDE 
            LEFT JOIN rnp.REGISTRO_CO_CARGO CA ON OA.ID_CARGO = CA.ID_CARGO
            INNER JOIN rnp.REGISTRO_BASE01_A B ON OA.CO_EXP_RNC=B.CO_EXP_RNC
            inner join emp on oa.lt_ruc=emp.lt_ruc
            inner join rnp_exp on oa.lt_ruc=rnp_exp.lt_ruc
            WHERE OA.ACTIVO=1 AND OA.NO_EXP=rnp_exp.NO_EXP
		AND OA.ACTIVO=1  
        )  X
        ORDER BY X.TIPO_COMP,X.ID_TABLA DESC 