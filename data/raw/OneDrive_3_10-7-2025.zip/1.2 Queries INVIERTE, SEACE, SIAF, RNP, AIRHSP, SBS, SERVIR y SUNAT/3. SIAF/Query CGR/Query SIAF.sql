select acu.act_proy,acu.ano_eje, 
CASE eje.tipo_unidad WHEN 'R' THEN 'GOBIERNO REGIONAL'
WHEN 'M' THEN 'GOBIERNO LOCAL'
WHEN 'E' THEN 'GOBIERNO NACIONAL'
ELSE ' ' END NIVEL,
eje.nombre EJECUTORA, 
fue.nombre fuente_financ,
comp.nombre COMPONENTE,
gene.descripcion generica,
subg.descripcion subgenerica,
subd.descripcion subgenerica_det,
espe.descripcion especifica,
edet.descripcion especifica_det,
dep.nombre departamento,
prov.nombre provincia,
dis.nombre distrito,

sum(PIA) PIA, sum(PIM) PIM, sum(MONTO_CERTIFICADO) MONTO_CERTIFICADO, sum(MONTO_COMPROMETIDO) MONTO_COMPROMETIDO,
sum(MONTO_COMPROMETIDO_ANUAL) MONTO_COMPROMETIDO_ANUAL, sum(MONTO_DEVENGADO) MONTO_DEVENGADO,
sum(MONTO_GIRADO) MONTO_GIRADO, sum(MONTO_PAGADO) MONTO_PAGADO

from MEF.acumulado_meta_2009 acu
inner join MEF.ejecutora eje on acu.sec_ejec = eje.sec_ejec and acu.ano_eje = eje.ano_eje
inner join MEF.fuente_financ fue on acu.fuente_financ = fue.fuente_financ and acu.ano_eje = fue.ano_eje
inner join MEF.componente_nombre comp on acu.componente = comp.componente and acu.ano_eje = comp.ano_eje
inner join MEF.generica gene on acu.generica = gene.generica and acu.ano_eje = gene.ano_eje
inner join MEF.subgenerica subg on acu.subgenerica = subg.subgenerica and acu.generica = subg.generica
and acu.ano_eje = subg.ano_eje
inner join MEF.subgenerica_det subd on acu.subgenerica_det = subd.subgenerica_det
and acu.subgenerica = subd.subgenerica and acu.generica = subd.generica and acu.ano_eje = subd.ano_eje
inner join MEF.especifica espe on acu.especifica = espe.especifica and acu.subgenerica_det = espe.subgenerica_det
and acu.subgenerica = espe.subgenerica and acu.generica = espe.generica and acu.ano_eje = espe.ano_eje
inner join MEF.especifica_det edet on acu.especifica_det = edet.especifica_det and acu.especifica = edet.especifica
and acu.subgenerica_det = edet.subgenerica_det
and acu.subgenerica = edet.subgenerica and acu.generica = edet.generica and acu.ano_eje = edet.ano_eje
inner join MEF.distrito dis on acu.distrito = dis.distrito and acu.provincia = dis.provincia and acu.departamento = dis.departamento
inner join MEF.provincia prov on acu.provincia = prov.provincia and acu.departamento = prov.departamento
inner join MEF.departamento dep on acu.departamento = dep.departamento

where acu.act_proy = '2517152' -- reemplazar CUI
and gene.tipo_transaccion = 2 and subg.tipo_transaccion = 2 and subd.tipo_transaccion = 2 and espe.tipo_transaccion = 2 and edet.tipo_transaccion = 2

group by acu.act_proy, acu.ano_eje, 
CASE eje.tipo_unidad WHEN 'R' THEN 'GOBIERNO REGIONAL'
WHEN 'M' THEN 'GOBIERNO LOCAL'
WHEN 'E' THEN 'GOBIERNO NACIONAL'
ELSE ' ' END,
eje.nombre, fue.nombre, 
comp.nombre, gene.descripcion, subg.descripcion, 
subd.descripcion, espe.descripcion, edet.descripcion,
dep.nombre, prov.nombre, dis.nombre, acu.mes_eje
